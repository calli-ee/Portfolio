<?php
$portfolio_config = [
    'name' => 'Caille Louis F. Aquino',
    'title' => 'Aspiring Full Stack Developer',
    'description' => '',
    'email' => 'caaquino@my.cspc.edu.ph',
    'phone' => '+63 981 397 9639',
    'location' => 'Naga City, Camarines Sur, PH',
    'facebook' => 'https://www.facebook.com/caille.aquino.1019',
    'instagram' => 'https://www.instagram.com/callii.ee',
    'github' => 'https://github.com/calli-ee'
];

$skills = [
    ['name' => 'PHP', 'level' => 90],
    ['name' => 'JavaScript', 'level' => 80],
    ['name' => 'Python', 'level' => 75],
    ['name' => 'React', 'level' => 70],
    ['name' => 'MySQL', 'level' => 84],
    ['name' => 'C++', 'level' => 95],
    ['name' => 'HTML/CSS', 'level' => 93],
    ['name' => 'Node.js', 'level' => 77],
    ['name' => 'Java', 'level' => 80]
];

$projects = [
    [
        'title' => 'Mini Appointment System (C++)',
        'description' => 'A console-based appointment scheduling application with CRUD functionalities',
        'technologies' => ['C++', 'Math Libraries'],
        'image' => 'screenshots/mini appointment system.png',
        'demo' => '#',
        'github' => 'https://github.com/calli-ee/Mini-Appointment-System-C-.git'
    ],
    [
        'title' => 'Flower Shop (C++)',
        'description' => 'A console application for managing flower shop inventory and sales',
        'technologies' => ['C++', 'Math Libraries'],
        'image' => 'screenshots/Flower Shop.png',
        'demo' => '#',
        'github' => 'https://github.com/calli-ee/Flower-Shop.git'
    ],
    [
        'title' => 'Inventory Management System (C++)',
        'description' => 'A console application for tracking and managing inventory levels, orders, and suppliers',
        'technologies' => ['C++', 'Math Libraries'],
        'image' => 'screenshots/Inventory Management System.png',
        'demo' => '#',
        'github' => 'https://github.com/calli-ee/Inventory-Management-System.git'
    ],
    [
        'title' => 'Mini Mart (C++)',
        'description' => 'A console application simulating a mini mart system with inventory and sales management features',
        'technologies' => ['C++', 'Math Libraries'],
        'image' => 'screenshots/Mini Mart.png',
        'demo' => '#',
        'github' => 'https://github.com/calli-ee/Mini-Mart-C-.git'
    ],
    [
        'title' => 'Emergency Response App',
        'description' => 'A school based mobile app for emergency reporting and response coordination',
        'technologies' => ['Node.js', 'React Native'],
        'image' => 'screenshots/Emergency Response App.png',
        'demo' => '#',
        'github' => 'https://github.com/calli-ee/Emergency-Response-App.git'
    ],
    [
        'title' => 'Cementery Management System',
        'description' => 'A web application for managing cemetery plots, burials, and maintenance schedules',
        'technologies' => ['Java'],
        'image' => 'screenshots/Cementery Management System.png',
        'demo' => '#',
        'github' => 'https://github.com/calli-ee/Cementery-Management-System.git'
    ],
    [
        'title' => 'Digital Retail Integration for Vehicle Enterprises (DRIVE)',
        'description' => 'A web-based platform for vehicle enterprises to manage sales, inventory, and customer relationships',
        'technologies' => ['PHP', 'MySQL', 'JavaScript', 'HTML', 'CSS'],
        'image' => 'screenshots/DRIVE.png',
        'demo' => '#',
        'github' => 'https://github.com/calli-ee/Digital-Retail-Integration-for-Vehicle-Enterprises-DRIVE-.git'
    ],
    [
        'title' => 'Personal Portfolio Website',
        'description' => 'Dynamic portfolio website built with PHP and MySQL for web development class',
        'technologies' => ['PHP', 'MySQL', 'HTML', 'CSS', 'JavaScript'],
        'image' => 'screenshots/portfolio.png',
        'demo' => '#',
        'github' => 'https://github.com/calli-ee/Portfolio.git'
    ]
];

$experiences = [
    [
        'title' => 'Web Development Projects',
        'company' => 'BSIT Program - CSPC',
        'period' => '2025 - Present',
        'description' => 'Developing various web applications using PHP, MySQL, and JavaScript as part of my BSIT curriculum. Focus on database design and dynamic web content.'
    ],
    [
        'title' => 'Database Management Systems',
        'company' => 'BSIT Program - CSPC',
        'period' => '2024 - 2025',
        'description' => 'Gained hands-on experience in designing and managing relational databases using MySQL. Implemented CRUD operations and optimized queries for performance.'
    ],
    [
        'title' => 'Programming Fundamentals',
        'company' => 'BSIT Program - CSPC',
        'period' => '2023 - 2024',
        'description' => 'Mastered C++ programming concepts including object-oriented programming, data structures, and algorithm implementation.'
    ],
    [
        'title' => 'Essentials for Arduino Programming',
        'company' => 'STEM Program - CSNHS',
        'period' => '2022 - 2023',
        'description' => 'Learned the basics of Arduino programming and electronics, creating simple projects that integrate hardware and software components.'
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caille's Portfolio</title>

    <link rel="apple-touch-icon" sizes="180x180" href="favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon_io/favicon-16x16.png">
    <link rel="manifest" href="favicon_io/site.webmanifest">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-bg: #0a0a0b;
            --secondary-bg: #121214;
            --tertiary-bg: #1a1a1d;
            --card-bg: #1e1e21;
            --primary-text: #f8f9fa;
            --secondary-text: #b8bcc8;
            --accent-color: #8B0000;
            --accent-hover: #a50000;
            --accent-light: rgba(139, 0, 0, 0.1);
            --accent-glow: rgba(139, 0, 0, 0.3);
            --border-color: #2d2d32;
            --glass-bg: rgba(18, 18, 20, 0.85);
            --glass-border: rgba(139, 0, 0, 0.15);
            --shadow-dark: rgba(0, 0, 0, 0.8);
            --gradient-primary: linear-gradient(135deg, var(--primary-bg) 0%, var(--secondary-bg) 50%, var(--tertiary-bg) 100%);
            --gradient-accent: linear-gradient(135deg, var(--accent-color) 0%, #660000 100%);
            --gradient-card: linear-gradient(145deg, rgba(30, 30, 33, 0.9) 0%, rgba(18, 18, 20, 0.9) 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.7;
            color: var(--primary-text);
            background: var(--primary-bg);
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--secondary-bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--accent-color);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-hover);
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 80%, rgba(139, 0, 0, 0.05) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(139, 0, 0, 0.03) 0%, transparent 50%),
                        radial-gradient(circle at 40% 40%, rgba(139, 0, 0, 0.02) 0%, transparent 50%);
            z-index: -1;
            animation: particles 20s ease-in-out infinite alternate;
        }

        @keyframes particles {
            0%, 100% { 
                transform: translateY(0px) rotate(0deg);
                opacity: 1;
            }
            50% { 
                transform: translateY(-20px) rotate(180deg);
                opacity: 0.8;
            }
        }

        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            background: var(--glass-bg);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border-bottom: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.2rem 0;
            transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
        }

        .navbar.scrolled {
            background: rgba(10, 10, 11, 0.95);
            backdrop-filter: blur(25px) saturate(200%);
            border-bottom: 1px solid var(--accent-color);
            box-shadow: 0 8px 32px rgba(139, 0, 0, 0.15);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary-text);
            text-decoration: none;
            position: relative;
            transition: all 0.3s ease;
        }

        .logo::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: var(--gradient-accent);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .logo:hover::after {
            transform: scaleX(1);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2.5rem;
        }

        .nav-links a {
            color: var(--secondary-text);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            position: relative;
            padding: 0.5rem 0;
            transition: all 0.3s cubic-bezier(0.4, 0.0, 0.2, 1);
        }

        .nav-links a::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: var(--gradient-accent);
            transform: translateX(-50%);
            transition: width 0.3s ease;
        }

        .nav-links a:hover {
            color: var(--primary-text);
        }

        .nav-links a:hover::before {
            width: 100%;
        }

        .hero {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: url('background.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(10, 10, 11, 0.9) 0%, rgba(18, 18, 20, 0.8) 40%, rgba(139, 0, 0, 0.1) 70%, rgba(26, 26, 29, 0.9) 100%);
            backdrop-filter: blur(3px);
        }

        .hero::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(139, 0, 0, 0.15) 0%, transparent 70%);
            transform: translate(-50%, -50%);
            animation: pulse 4s ease-in-out infinite alternate;
        }

        @keyframes pulse {
            0% { 
                transform: translate(-50%, -50%) scale(0.8);
                opacity: 0.5;
            }
            100% { 
                transform: translate(-50%, -50%) scale(1.2);
                opacity: 0.8;
            }
        }

        .hero-content {
            text-align: center;
            z-index: 2;
            max-width: 900px;
            padding: 0 2rem;
            background: var(--glass-bg);
            backdrop-filter: blur(25px) saturate(180%);
            border-radius: 30px;
            border: 1px solid var(--glass-border);
            padding: 4rem 3rem;
            box-shadow: 0 25px 50px var(--shadow-dark);
            position: relative;
            overflow: hidden;
        }

        .hero-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--accent-color), transparent);
        }

        .hero-title {
            font-size: 4.5rem;
            font-weight: 800;
            margin-bottom: 1.5rem;
            background: linear-gradient(135deg, var(--primary-text) 0%, var(--accent-color) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: fadeInUp 1s ease;
            line-height: 1.1;
        }

        .hero-subtitle {
            font-size: 1.8rem;
            color: var(--accent-color);
            margin-bottom: 1.5rem;
            font-weight: 600;
            animation: fadeInUp 1s ease 0.2s both;
        }

        .hero-subtitle .cursor {
            display: inline-block;
            animation: blink 1s infinite;
        }

        @keyframes blink {
            0%, 50% { opacity: 1; }
            51%, 100% { opacity: 0; }
        }

        .hero-description {
            font-size: 1.3rem;
            margin-bottom: 2.5rem;
            color: var(--secondary-text);
            animation: fadeInUp 1s ease 0.4s both;
            font-weight: 400;
        }

        .cta-button {
            display: inline-block;
            background: var(--gradient-accent);
            color: var(--primary-text);
            padding: 1.2rem 3rem;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
            animation: fadeInUp 1s ease 0.6s both;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 30px var(--accent-glow);
        }

        .cta-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.6s ease;
        }

        .cta-button:hover::before {
            left: 100%;
        }

        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 40px var(--accent-glow);
        }

        .section {
            padding: 6rem 0;
            max-width: 1400px;
            margin: 0 auto;
            padding-left: 2rem;
            padding-right: 2rem;
            position: relative;
        }

        .section-title {
            font-size: 3rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 4rem;
            position: relative;
            background: linear-gradient(135deg, var(--primary-text) 0%, var(--accent-color) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: var(--gradient-accent);
            border-radius: 2px;
        }

        .about {
            background: var(--gradient-primary);
            position: relative;
        }

        .about::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(139,0,0,0.05)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
            opacity: 0.3;
        }

        .about-content {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 4rem;
            align-items: center;
            position: relative;
            z-index: 1;
        }

        .about-left {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 2rem;
        }

        .about-image {
            width: 350px;
            height: 350px;
            border-radius: 30px;
            margin: 0 auto;
            border: 2px solid var(--accent-color);
            box-shadow: 0 30px 60px var(--shadow-dark);
            overflow: hidden;
            position: relative;
            transition: transform 0.4s ease;
        }

        .about-image::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(139, 0, 0, 0.1) 50%, transparent 70%);
            z-index: 1;
            transition: opacity 0.3s ease;
        }

        .about-image:hover {
            transform: scale(1.05);
        }

        .about-image:hover::before {
            opacity: 0;
        }

        .about-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 28px;
            transition: transform 0.4s ease;
        }

        .profile-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
        }

        .profile-btn {
            background: var(--gradient-accent);
            color: var(--primary-text);
            padding: 0.8rem 1.5rem;
            text-decoration: none;
            border-radius: 25px;
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 5px 15px var(--accent-glow);
        }

        .profile-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px var(--accent-glow);
        }

        .about-text {
            font-size: 1.2rem;
            color: var(--secondary-text);
            line-height: 1.8;
            background: var(--gradient-card);
            padding: 3rem;
            border-radius: 25px;
            border: 1px solid var(--border-color);
            box-shadow: 0 20px 40px var(--shadow-dark);
            position: relative;
            overflow: hidden;
        }

        .about-text::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: var(--gradient-accent);
        }

        .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2.5rem;
        }

        .skill-item {
            background: var(--gradient-card);
            padding: 2rem;
            border-radius: 20px;
            border: 1px solid var(--border-color);
            backdrop-filter: blur(20px);
            transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .skill-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--accent-color), transparent);
        }

        .skill-item:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px var(--shadow-dark);
            border-color: var(--accent-color);
        }

        .skill-name {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            font-weight: 600;
            font-size: 1.1rem;
        }

        .skill-percentage {
            color: var(--accent-color);
            font-weight: 700;
        }

        .skill-bar {
            background: var(--tertiary-bg);
            height: 12px;
            border-radius: 6px;
            overflow: hidden;
            position: relative;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .skill-progress {
            height: 100%;
            background: var(--gradient-accent);
            border-radius: 6px;
            transition: width 1.5s cubic-bezier(0.4, 0.0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .skill-progress::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            animation: shimmer 3s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .projects {
            background: var(--gradient-primary);
            position: relative;
        }

        .projects::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 30% 70%, rgba(139, 0, 0, 0.08) 0%, transparent 50%),
                        radial-gradient(circle at 70% 30%, rgba(139, 0, 0, 0.05) 0%, transparent 50%);
        }

        .projects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(380px, 1fr));
            gap: 2.5rem;
            position: relative;
            z-index: 1;
        }

        .project-card {
            background: var(--gradient-card);
            border-radius: 25px;
            overflow: hidden;
            transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
            border: 1px solid var(--border-color);
            backdrop-filter: blur(20px);
            position: relative;
            group: hover;
        }

        .project-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(139, 0, 0, 0.1) 0%, transparent 50%, rgba(139, 0, 0, 0.05) 100%);
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: -1;
        }

        .project-card:hover::before {
            opacity: 1;
        }

        .project-card:hover {
            transform: translateY(-15px) scale(1.02);
            box-shadow: 0 30px 60px var(--shadow-dark);
            border-color: var(--accent-color);
        }

        .project-image {
            width: 100%;
            height: 220px;
            object-fit: cover;
            transition: transform 0.6s ease;
        }

        .project-card:hover .project-image {
            transform: scale(1.1);
        }

        .project-content {
            padding: 2rem;
        }

        .project-title {
            font-size: 1.4rem;
            margin-bottom: 1rem;
            color: var(--primary-text);
            font-weight: 600;
        }

        .project-description {
            color: var(--secondary-text);
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .project-tech {
            display: flex;
            flex-wrap: wrap;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
        }

        .tech-tag {
            background: var(--accent-light);
            color: var(--accent-color);
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            border: 1px solid rgba(139, 0, 0, 0.3);
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .tech-tag:hover {
            background: var(--accent-color);
            color: var(--primary-text);
            transform: translateY(-2px);
        }

        .project-links {
            display: flex;
            gap: 1.5rem;
        }

        .project-link {
            color: var(--accent-color);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
            padding: 0.5rem 0;
        }

        .project-link:hover {
            color: var(--primary-text);
            transform: translateX(5px);
        }

        .experience-timeline {
            position: relative;
            padding-left: 3rem;
        }

        .experience-timeline::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--gradient-accent);
            border-radius: 1.5px;
        }

        .experience-item {
            position: relative;
            margin-bottom: 3rem;
            background: var(--gradient-card);
            padding: 2.5rem;
            border-radius: 20px;
            border: 1px solid var(--border-color);
            backdrop-filter: blur(20px);
            transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
        }

        .experience-item::before {
            content: '';
            position: absolute;
            left: -3.25rem;
            top: 2rem;
            width: 18px;
            height: 18px;
            background: var(--accent-color);
            border-radius: 50%;
            border: 3px solid var(--primary-bg);
            box-shadow: 0 0 20px var(--accent-glow);
        }

        .experience-item:hover {
            transform: translateX(15px);
            box-shadow: 0 20px 40px var(--shadow-dark);
            border-color: var(--accent-color);
        }

        .experience-title {
            font-size: 1.4rem;
            color: var(--primary-text);
            margin-bottom: 0.5rem;
            font-weight: 600;
        }

        .experience-company {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--accent-color);
        }

        .experience-period {
            color: var(--secondary-text);
            font-size: 0.95rem;
            margin-bottom: 1rem;
            font-weight: 500;
        }

        .experience-description {
            color: var(--secondary-text);
            line-height: 1.7;
        }

        .contact {
            background: var(--gradient-primary);
            position: relative;
        }

        .contact::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="dots" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="10" cy="10" r="1" fill="rgba(139,0,0,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23dots)"/></svg>');
            opacity: 0.5;
        }

        .contact-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            position: relative;
            z-index: 1;
        }

        .contact-info {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .contact-item {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            color: var(--secondary-text);
            background: var(--gradient-card);
            padding: 1.5rem;
            border-radius: 15px;
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
        }

        .contact-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px var(--shadow-dark);
            border-color: var(--accent-color);
        }

        .contact-icon {
            width: 50px;
            height: 50px;
            background: var(--gradient-accent);
            color: var(--primary-text);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-size: 1.2rem;
            box-shadow: 0 10px 20px var(--accent-glow);
        }

        .contact-item h4 {
            color: var(--primary-text);
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .social-links {
            display: flex;
            gap: 1.5rem;
            margin-top: 2rem;
            justify-content: center;
        }

        .social-link {
            width: 60px;
            height: 60px;
            background: var(--gradient-card);
            color: var(--accent-color);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            text-decoration: none;
            transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
            border: 1px solid var(--border-color);
            font-size: 1.3rem;
            position: relative;
            overflow: hidden;
        }

        .social-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: var(--gradient-accent);
            border-radius: 50%;
            transform: scale(0);
            transition: transform 0.3s ease;
            z-index: -1;
        }

        .social-link:hover::before {
            transform: scale(1);
        }

        .social-link:hover {
            color: var(--primary-text);
            transform: translateY(-5px);
            box-shadow: 0 15px 30px var(--accent-glow);
        }

        .contact-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            background: var(--gradient-card);
            padding: 3rem;
            border-radius: 25px;
            border: 1px solid var(--border-color);
            backdrop-filter: blur(20px);
            box-shadow: 0 20px 40px var(--shadow-dark);
            position: relative;
            overflow: hidden;
        }

        .contact-form::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--gradient-accent);
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 0.8rem;
            color: var(--primary-text);
            font-weight: 500;
            font-size: 1rem;
        }

        .form-group input,
        .form-group textarea {
            padding: 1.2rem;
            background: var(--tertiary-bg);
            border: 2px solid var(--border-color);
            border-radius: 12px;
            color: var(--primary-text);
            font-family: inherit;
            font-size: 1rem;
            transition: all 0.3s ease;
            resize: vertical;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--accent-color);
            box-shadow: 0 0 0 4px var(--accent-light);
            background: var(--card-bg);
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: var(--secondary-text);
        }

        .submit-btn {
            background: var(--gradient-accent);
            color: var(--primary-text);
            padding: 1.2rem 2rem;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 600;
            transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
            position: relative;
            overflow: hidden;
            margin-top: 1rem;
            box-shadow: 0 10px 30px var(--accent-glow);
        }

        .submit-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.6s ease;
        }

        .submit-btn:hover::before {
            left: 100%;
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 40px var(--accent-glow);
        }

        .submit-btn:active {
            transform: translateY(-1px);
        }

        .footer {
            background: var(--primary-bg);
            text-align: center;
            padding: 3rem 0;
            border-top: 1px solid var(--border-color);
            position: relative;
        }

        .footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: var(--gradient-accent);
        }

        .footer p {
            color: var(--secondary-text);
            font-size: 1rem;
        }

        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--primary-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            opacity: 1;
            transition: opacity 0.5s ease;
        }

        .loading-overlay.fade-out {
            opacity: 0;
            pointer-events: none;
        }

        .loader {
            width: 60px;
            height: 60px;
            border: 3px solid var(--border-color);
            border-top: 3px solid var(--accent-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .fade-in {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.8s cubic-bezier(0.4, 0.0, 0.2, 1);
        }

        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @media (max-width: 1024px) {
            .about-content,
            .contact-content {
                grid-template-columns: 1fr;
                gap: 3rem;
            }

            .hero-title {
                font-size: 3.5rem;
            }

            .section-title {
                font-size: 2.5rem;
            }
        }

        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }

            .hero-title {
                font-size: 2.8rem;
            }

            .hero-subtitle {
                font-size: 1.4rem;
            }

            .hero-content {
                padding: 2.5rem 2rem;
            }

            .about-content {
                text-align: center;
            }

            .about-image {
                width: 280px;
                height: 280px;
            }

            .section {
                padding-left: 1rem;
                padding-right: 1rem;
            }

            .experience-timeline {
                padding-left: 2rem;
            }

            .experience-item {
                padding: 1.5rem;
            }

            .contact-form {
                padding: 2rem;
            }

            .projects-grid,
            .skills-grid {
                grid-template-columns: 1fr;
            }

            .profile-buttons {
                flex-direction: column;
            }
        }

        @media (max-width: 480px) {
            .hero-title {
                font-size: 2.2rem;
            }

            .section-title {
                font-size: 2rem;
            }

            .nav-container {
                padding: 0 1rem;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        @media (prefers-contrast: high) {
            :root {
                --primary-text: #ffffff;
                --secondary-text: #cccccc;
                --accent-color: #ff0000;
                --border-color: #444444;
            }
        }
    </style>
</head>
<body>
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loader"></div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <a href="#home" class="logo"><?php echo $portfolio_config['name']; ?></a>
            <ul class="nav-links">
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#skills">Skills</a></li>
                <li><a href="#projects">Projects</a></li>
                <li><a href="#experience">Experience</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </div>
    </nav>

    <section id="home" class="hero">
        <div class="hero-content">
            <h1 class="hero-title"><?php echo $portfolio_config['name']; ?></h1>
            <h2 class="hero-subtitle"><?php echo $portfolio_config['title']; ?></h2>
            <p class="hero-description"><?php echo $portfolio_config['description']; ?></p>
            <a href="#projects" class="cta-button">View My Work</a>
        </div>
    </section>

    <section id="about" class="section about">
        <h2 class="section-title">About Me</h2>
        <div class="about-content fade-in">
            <div class="about-left">
                <div class="about-image">
                    <img src="me.png" alt="Caille Aquino" loading="lazy">
                </div>
                <div class="profile-buttons">
                    <a href="#" class="profile-btn">
                        <i class="fas fa-download"></i> Resume
                    </a>
                    <a href="#projects" class="profile-btn">
                        <i class="fas fa-code"></i> Portfolio
                    </a>
                </div>
            </div>
            <div class="about-text">
                <p>Hi! I'm Caille, a 3rd-year BSIT student at Camarines Sur Polytechnic Colleges, aspiring to be a full-stack developer. I started with C++, which helped me build problem-solving skills and a love for programming. I'm now expanding into web development, using PHP, JavaScript, and MySQL, while also learning modern frameworks such as React and Node.js. I'm eager to continue improving my skills, exploring new technologies, and taking on projects that challenge me to grow as a developer.</p>
            </div>
        </div>
    </section>

    <section id="skills" class="section">
        <h2 class="section-title">Skills</h2>
        <div class="skills-grid fade-in">
            <?php foreach ($skills as $skill): ?>
            <div class="skill-item">
                <div class="skill-name">
                    <span><?php echo $skill['name']; ?></span>
                    <span class="skill-percentage"><?php echo $skill['level']; ?>%</span>
                </div>
                <div class="skill-bar">
                    <div class="skill-progress" style="width: 0%" data-width="<?php echo $skill['level']; ?>%"></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section id="projects" class="section projects">
        <h2 class="section-title">Academic Projects</h2>
        <div class="projects-grid fade-in">
            <?php foreach ($projects as $project): ?>
            <div class="project-card">
                <img src="<?php echo $project['image']; ?>" alt="<?php echo $project['title']; ?>" class="project-image" loading="lazy">
                <div class="project-content">
                    <h3 class="project-title"><?php echo $project['title']; ?></h3>
                    <p class="project-description"><?php echo $project['description']; ?></p>
                    <div class="project-tech">
                        <?php foreach ($project['technologies'] as $tech): ?>
                        <span class="tech-tag"><?php echo $tech; ?></span>
                        <?php endforeach; ?>
                    </div>
                    <div class="project-links">
                        <a href="<?php echo $project['github']; ?>" class="project-link" target="_blank" rel="noopener noreferrer">
                            <i class="fab fa-github"></i> GitHub
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section id="experience" class="section">
        <h2 class="section-title">Educational Journey</h2>
        <div class="experience-timeline fade-in">
            <?php foreach ($experiences as $experience): ?>
            <div class="experience-item">
                <h3 class="experience-title"><?php echo $experience['title']; ?></h3>
                <h4 class="experience-company"><?php echo $experience['company']; ?></h4>
                <p class="experience-period"><?php echo $experience['period']; ?></p>
                <p class="experience-description"><?php echo $experience['description']; ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section id="contact" class="section contact">
        <h2 class="section-title">Get In Touch</h2>
        <div class="contact-content fade-in">
            <div class="contact-info">
                <div class="contact-item">
                    <div class="contact-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div>
                        <h4>Email</h4>
                        <p><?php echo $portfolio_config['email']; ?></p>
                    </div>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <div>
                        <h4>Phone</h4>
                        <p><?php echo $portfolio_config['phone']; ?></p>
                    </div>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div>
                        <h4>Location</h4>
                        <p><?php echo $portfolio_config['location']; ?></p>
                    </div>
                </div>
                <div class="social-links">
                    <a href="<?php echo $portfolio_config['facebook']; ?>" class="social-link" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="<?php echo $portfolio_config['instagram']; ?>" class="social-link" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="<?php echo $portfolio_config['github']; ?>" class="social-link" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-github"></i>
                    </a>
                </div>
            </div>
            <form class="contact-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" placeholder="Your full name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="your.email@example.com" required>
                </div>
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" placeholder="What's this about?" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" placeholder="Your message here..." required></textarea>
                </div>
                <button type="submit" class="submit-btn">
                    <i class="fas fa-paper-plane"></i> Send Message
                </button>
            </form>
        </div>
    </section>

    <footer class="footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo $portfolio_config['name']; ?>. All rights reserved.</p>
    </footer>

    <script>
        window.addEventListener('load', function() {
            const loadingOverlay = document.getElementById('loadingOverlay');
            setTimeout(() => {
                loadingOverlay.classList.add('fade-out');
                setTimeout(() => {
                    loadingOverlay.style.display = 'none';
                }, 500);
            }, 1000);
        });

        let ticking = false;
        function updateParallax() {
            const scrolled = window.pageYOffset;
            const hero = document.querySelector('.hero');
            
            if (hero && window.innerWidth > 768) {
                const rate = scrolled * 0.3;
                hero.style.backgroundPosition = `center calc(50% + ${rate}px)`;
            }
            ticking = false;
        }

        window.addEventListener('scroll', function() {
            if (!ticking) {
                requestAnimationFrame(updateParallax);
                ticking = true;
            }
        });

        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    const navHeight = document.querySelector('.navbar').offsetHeight;
                    const targetPosition = target.offsetTop - navHeight;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });

        const navbar = document.getElementById('navbar');
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    
                    if (entry.target.id === 'skills') {
                        const skillBars = entry.target.querySelectorAll('.skill-progress');
                        skillBars.forEach((bar, index) => {
                            setTimeout(() => {
                                const width = bar.getAttribute('data-width');
                                bar.style.width = width;
                            }, index * 100);
                        });
                    }
                }
            });
        }, observerOptions);

        document.querySelectorAll('.fade-in').forEach(el => {
            observer.observe(el);
        });

        const skillsSection = document.querySelector('#skills');
        if (skillsSection) {
            observer.observe(skillsSection);
        }

        const contactForm = document.querySelector('.contact-form');
        const submitBtn = document.querySelector('.submit-btn');
        
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
                submitBtn.disabled = true;
                
                setTimeout(() => {
                    submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
                    submitBtn.disabled = false;
                }, 3000);
            });
        }

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                document.body.classList.add('keyboard-navigation');
            }
        });

        document.addEventListener('mousedown', function() {
            document.body.classList.remove('keyboard-navigation');
        });

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo "
            setTimeout(() => {
                alert('Thank you for your message! I will get back to you soon.');
            }, 500);
            ";
        }
        ?>

        function typeWriter(element, text, speed = 100) {
            element.innerHTML = '';
            let i = 0;
            
            function type() {
                if (i < text.length) {
                    element.innerHTML = text.substring(0, i + 1) + '<span class="cursor">|</span>';
                    i++;
                    setTimeout(type, speed);
                } else {
                    element.innerHTML = text + '<span class="cursor">|</span>';
                }
            }
            
            type();
        }

        window.addEventListener('load', function() {
            setTimeout(() => {
                const subtitle = document.querySelector('.hero-subtitle');
                if (subtitle) {
                    const originalText = subtitle.textContent;
                    typeWriter(subtitle, originalText, 80);
                }
            }, 1500);
        });
    </script>
</body>
</html>